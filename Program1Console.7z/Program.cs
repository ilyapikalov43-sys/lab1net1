﻿using System;

namespace ConstructionAreaCalculator
{
    /// <summary>
    /// Главный класс программы для расчёта площади строительных объектов.
    /// </summary>
    class Program
    {
        /// <summary>
        /// Точка входа в приложение.
        /// </summary>
        static void Main(string[] args)
        {
            // Устанавливаем заголовок окна консоли
            Console.Title = "Калькулятор площади строительных объектов v1.0";
            bool exitRequested = false;

            // Главный цикл программы (работает, пока пользователь не выйдет)
            while (!exitRequested)
            {
                try
                {
                    // Отображение меню
                    Console.Clear();
                    Console.WriteLine("=============================================");
                    Console.WriteLine("   КАЛЬКУЛЯТОР ПЛОЩАДИ СТРОИТЕЛЬНЫХ ОБЪЕКТОВ");
                    Console.WriteLine("=============================================");
                    Console.WriteLine("Выберите тип объекта для расчёта:");
                    Console.WriteLine("1. Прямоугольник (S = a * b)");
                    Console.WriteLine("2. Треугольник (S = (a * h) / 2)");
                    Console.WriteLine("3. Круг (S = π * r²)");
                    Console.WriteLine("0. Выход");
                    Console.WriteLine("---------------------------------------------");
                    Console.Write("Ваш выбор: ");

                    string? input = Console.ReadLine();
                    Console.WriteLine(); // Пустая строка для читаемости

                    // Обработка выбора пользователя
                    switch (input)
                    {
                        case "1":
                            CalculateRectangleArea();
                            break;
                        case "2":
                            CalculateTriangleArea();
                            break;
                        case "3":
                            CalculateCircleArea();
                            break;
                        case "0":
                            exitRequested = true;
                            Console.WriteLine("Выход из программы. До свидания!");
                            break;
                        default:
                            Console.WriteLine("Ошибка: Неверный пункт меню. Пожалуйста, введите число от 0 до 3.");
                            break;
                    }

                    // Если не выходим, ждем нажатия клавиши, чтобы пользователь увидел результат
                    if (!exitRequested)
                    {
                        Console.WriteLine("\nНажмите любую клавишу, чтобы вернуться в меню...");
                        Console.ReadKey();
                    }
                }
                catch (Exception ex)
                {
                    // Глобальный обработчик непредвиденных ошибок
                    Console.WriteLine($"\nПроизошла критическая ошибка: {ex.Message}");
                    Console.WriteLine("Нажмите любую клавишу для перезапуска меню...");
                    Console.ReadKey();
                }
            }
        }

        /// <summary>
        /// Безопасно считывает положительное число с плавающей точкой из консоли.
        /// Реализует валидацию входных данных и защиту от деления на ноль (если параметр allowZero = false).
        /// </summary>
        /// <param name="prompt">Текст приглашения для ввода.</param>
        /// <param name="allowZero">Разрешать ли ввод нуля (для сторон прямоугольника - нет, для радиуса - да).</param>
        /// <returns>Положительное число (double), введенное пользователем.</returns>
        static double GetPositiveDouble(string prompt, bool allowZero = false)
        {
            double value;
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();

                // Проверка 1: является ли число числом?
                if (!double.TryParse(input, out value))
                {
                    Console.WriteLine("Ошибка: Введите корректное число (используйте запятую как разделитель).");
                    continue;
                }

                // Проверка 2: является ли число положительным?
                if (value <= 0)
                {
                    if (allowZero && value == 0)
                    {
                        // Если разрешен ноль и введен ноль, пропускаем (для радиуса не актуально, но оставим)
                        return value;
                    }
                    Console.WriteLine("Ошибка: Значение должно быть положительным числом (больше нуля).");
                    continue;
                }

                // Если все проверки пройдены
                return value;
            }
        }

        /// <summary>
        /// Метод для расчёта площади прямоугольника.
        /// </summary>
        static void CalculateRectangleArea()
        {
            Console.WriteLine("--- РАСЧЁТ ПЛОЩАДИ ПРЯМОУГОЛЬНИКА ---");
            Console.WriteLine("Введите длины сторон (a и b).");

            // Валидация не пропустит 0 или отрицательные числа
            double sideA = GetPositiveDouble("Введите сторону a (м): ");
            double sideB = GetPositiveDouble("Введите сторону b (м): ");

            // Алгоритм расчёта: S = a * b
            double area = sideA * sideB;

            Console.WriteLine($"\nРезультат: Площадь прямоугольника со сторонами {sideA} м и {sideB} м равна {area:F3} кв.м.");
        }

        /// <summary>
        /// Метод для расчёта площади треугольника.
        /// </summary>
        static void CalculateTriangleArea()
        {
            Console.WriteLine("--- РАСЧЁТ ПЛОЩАДИ ТРЕУГОЛЬНИКА ---");
            Console.WriteLine("Введите длину основания и высоту (a и h).");

            double baseSide = GetPositiveDouble("Введите длину основания a (м): ");
            double height = GetPositiveDouble("Введите высоту h (м): ");

            // Алгоритм расчёта: S = (a * h) / 2
            // Защита от деления на ноль обеспечивается валидацией (height > 0)
            double area = (baseSide * height) / 2;

            Console.WriteLine($"\nРезультат: Площадь треугольника с основанием {baseSide} м и высотой {height} м равна {area:F3} кв.м.");
        }

        /// <summary>
        /// Метод для расчёта площади круга.
        /// </summary>
        static void CalculateCircleArea()
        {
            Console.WriteLine("--- РАСЧЁТ ПЛОЩАДИ КРУГА ---");

            double radius = GetPositiveDouble("Введите радиус круга r (м): ");

            // Алгоритм расчёта: S = π * r²
            // Math.Pow - возведение в степень, Math.PI - число Пи
            double area = Math.PI * Math.Pow(radius, 2);

            Console.WriteLine($"\nРезультат: Площадь круга с радиусом {radius} м равна {area:F3} кв.м.");
        }
    }
}